<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Items;

class ItemsController extends Controller
{
    function index()
    {
        $data= Items::all();

       return view('home',['items'=>$data]);
    }
}
