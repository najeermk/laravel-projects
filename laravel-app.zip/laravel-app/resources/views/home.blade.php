@extends('layout')

@section('content')


 <div class="container">
  
  <div class="row">
  	@foreach ($items as $item)
	  	<div class="col-sm">

	  		<img src="{{$item->photo]}}" width="250px">
	  		<h5>{{ $item->name }}</h5>	  		
	  		<p>{{ $item->price }}</p>
	  		

	  	</div>
	@endforeach
</div>
</div>


@endsection