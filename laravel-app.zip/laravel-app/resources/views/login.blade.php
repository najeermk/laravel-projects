
@extends('layout')

@section('content')

<div class="container">
	<h1>LOGIN</h1>
	<br>
<form method="POST" action="{{ route('login') }}" >
	@csrf
  <div class="row">
    
    <div class="col">
      <input type="email" class="form-control" name="email" placeholder="email">
       </div>
      <div class="col">
      <input type="password" class="form-control" name="pass" placeholder="password">
   
    </div>
  </div>
  <br>
      <button type="submit" name="submit" class="btn btn-primary">Login</button>

 
</form>
</div>

@endsection