
@extends('layout')

@section('content')


<div class="container">
	<h1>SIGN UP</h1>
	<br>
<form method="POST" action="{{ route('signup') }}">
	@csrf
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" name="name" placeholder="name">
    </div>
    <div class="col">
      <input type="email" class="form-control" name="email" placeholder="email">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col">
      <input type="password" class="form-control" name="pass" placeholder="password">
    </div>
    <div class="col">
      <input type="text" class="form-control" name="phone" placeholder="phone">
    </div>
  </div>
  
  <br>
  		<input value="sign up" type="submit" name="submit" class="btn btn-primary" > 
 
</form>
</div>


@endsection