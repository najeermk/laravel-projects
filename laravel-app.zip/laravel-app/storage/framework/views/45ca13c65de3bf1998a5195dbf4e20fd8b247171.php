


<?php $__env->startSection('content'); ?>


<div class="container">
	<h1>SIGN UP</h1>
	<br>
<form method="POST" action="<?php echo e(route('signup')); ?>">
	<?php echo csrf_field(); ?>
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" name="name" placeholder="name">
    </div>
    <div class="col">
      <input type="email" class="form-control" name="email" placeholder="email">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col">
      <input type="password" class="form-control" name="pass" placeholder="password">
    </div>
    <div class="col">
      <input type="text" class="form-control" name="phone" placeholder="phone">
    </div>
  </div>
  
  <br>
  		<input value="sign up" type="submit" name="submit" class="btn btn-primary" > 
 
</form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/signup.blade.php ENDPATH**/ ?>