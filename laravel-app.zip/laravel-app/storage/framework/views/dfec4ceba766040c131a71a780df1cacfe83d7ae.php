

<?php $__env->startSection('content'); ?>
<?php 
use App\Http\Controllers\ProductController;

?>

 <div class="container">
  
  <div class="row">
  	<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  	<div class="col-sm">

	  		<img src="<?php echo e($item['photo']); ?>" width="250px">
	  		<h5><?php echo e($item['name']); ?></h5>	  		
	  		<p><?php echo e($item['price']); ?></p>
	  		

	  	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-app\resources\views/home.blade.php ENDPATH**/ ?>